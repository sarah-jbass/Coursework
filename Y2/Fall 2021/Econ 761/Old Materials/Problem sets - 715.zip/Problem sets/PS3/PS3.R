#################
# Problem set 2 #
# Natalia Serna #
#################

rm(list=ls())
library(MASS)
library(expm)
library(doParallel)
library(doRNG)
cl <- makeCluster(2)
registerDoParallel(cl)
setwd("~/Documents/Ph.D/Econ 715 - Econometric Methods/Problem sets/PS3/")
source("ghk_rho.R")
sims <- 1000
n <- 200
boot <- 1000
M <- 10

#Part 3.a)
set.seed(1234)
res_a <- foreach(i=1:sims, .combine=rbind, .packages="MASS")%dorng%{
  p <- optim(par=0.005, ghk_rho, p=0, n=n, M=M, lower=-1, upper=1) 
  p_hat <- p$par 
  f <- ghk_rho(rho=p_hat, p=0, n=n, M=M)
  gh <- cbind(g11-colMeans(g11),g22-colMeans(g22)) 
  Sig <- (t(gh)%*%gh)/n
  var <- solve(t(G)%*%G)%*%(t(G)%*%(Sig)%*%G)%*%solve(t(G)%*%G)/n
  W <- p_hat/sqrt(var)
  c(p_hat, as.numeric(abs(W)>=qnorm(0.975)))
}

mean(res_a[,1])
sd(res_a[,1])
mean(res_a[,2])


#Part 3.b)
set.seed(1234)
res_b <- foreach(i=1:sims, .combine=rbind, .packages=c("MASS", "doParallel"))%dorng%{
  p <- optim(par=0.001, ghk_rho, p=0, n=n, M=M, lower=-1, upper=1) 
  p_hat <- p$par
  f <- ghk_rho(rho=p_hat, p=0, n=n, M=M)
  gh <- cbind(g11-colMeans(g11),g22-colMeans(g22)) 
  Sig <- (t(gh)%*%gh)/n
  var <- solve(t(G)%*%G)%*%(t(G)%*%(Sig)%*%G)%*%solve(t(G)%*%G)/n
  W <- p_hat/sqrt(var)
  Wb <- foreach(j=1:boot, .combine=rbind, .packages="MASS")%dorng%{
    p <- optim(par=0.001, ghk_rho, p=p_hat, n=n, M=M, lower=-1, upper=1) 
    p_boot <- p$par
    f <- ghk_rho(rho=p_boot, p=p_hat, n=n, M=M)
    gh <- cbind(g11-colMeans(g11),g22-colMeans(g22)) 
    Sig <- t(gh)%*%gh/n
    varb <- solve(t(G)%*%G)%*%(t(G)%*%(Sig)%*%G)%*%solve(t(G)%*%G)/n
    c((p_boot-p_hat)/sqrt(varb),(p_boot-p_hat)/sqrt(var), p_boot)
  }  
  crit <- apply(Wb[,1:2], 2, FUN=function(x){quantile(abs(x), 0.95)})
  se_b <- sd(Wb[,3])
  c(p_hat, as.numeric(abs(W)>=crit[1]),as.numeric(abs(W)>=crit[2]),as.numeric(abs(p_hat/se_b)>=qnorm(0.975)))
}
mean(res_b[,1])
sd(res_b[,1])
mean(res_b[,2])
mean(res_b[,3])
mean(res_b[,4])

#Part 3.c)
library(doParallel)
cl <- makeCluster(2)
registerDoParallel(cl)
source("ghk_rho_b.R")
set.seed(1234)
res_c <- foreach(i=1:sims, .combine=rbind, .packages=c("MASS", "doParallel")) %dorng% {
  p <- optim(par=0.005, ghk_rho, p=0, n=n, M=M, lower=-1, upper=1) 
  p_hat <- p$par
  f <- ghk_rho(rho=p_hat, p=0, n=n, M=M)
  gh <- cbind(g11-colMeans(g11),g22-colMeans(g22)) 
  Sig <- (t(gh)%*%gh)/n
  var <- solve(t(G)%*%G)%*%(t(G)%*%(Sig)%*%G)%*%solve(t(G)%*%G)/n
  W <- p_hat/sqrt(var)
  set.seed(1111)
  Wb <- foreach(j=1:boot, .combine=rbind, .packages="MASS") %dorng% {   
    samp <- sample.int(n, size = n, replace = T)
    p <- optim(par=0.005, ghk_rho_b, n=n, M=M, mg=gbs, data=datan[samp,], lower=-1, upper=1) 
    p_boot <- p$par
    f <- ghk_rho_b(rho=p_boot, n=n, M=M, mg=gbs, data=datan[samp,])
    gh <- cbind(g11-colMeans(g11),g22-colMeans(g22)) 
    Sig <- t(gh)%*%gh/n
    varb <- solve(t(G)%*%G)%*%(t(G)%*%(Sig)%*%G)%*%solve(t(G)%*%G)/n
    c((p_boot-p_hat)/sqrt(varb),(p_boot-p_hat)/sqrt(var), p_boot)
  }  
  crit <- apply(Wb[,1:2], 2, FUN=function(x){quantile(abs(x), 0.95)})
  se_b <- sd(Wb[,3])
  c(p_hat, as.numeric(abs(W)>=crit[1]),as.numeric(abs(W)>=crit[2]),as.numeric(abs(p_hat/se_b)>=qnorm(0.975)))  
}
mean(res_c[,1])
sd(res_c[,1])
mean(res_c[,2])
mean(res_c[,3])
mean(res_c[,4])

