ghk_rho_b=function(rho, n, M, mg, data){
  
  #Step 1  
  y1=data[,1]
  y2=data[,2]
  
  #Step 2
  id <- matrix(c(rep(0,n)),n,1)
  D <- matrix(c(rep(0,n)),n,1)
  for(m in 3:(M+2)){
    u <- data[,m]
    eta <- qnorm(u*(1-pnorm(0))+pnorm(0))
    id <- id + (1-pnorm(0))*pnorm((1-rho)*eta/sqrt(1-rho^2))
    D <- D + (-1)*(1-pnorm(0))*dnorm((1-rho)*eta/sqrt(1-rho^2))*eta*((rho-1)/((1-rho^2)^1.5))
  }  
  id <- id/M
  G <<- colMeans(cbind(D/M, D/M))
  g1 <- y1-id
  g11 <<- g1
  g2 <- y2-id
  g22 <<- g2
  g <- cbind(g1,g2) 
  gb <- colMeans(g)
  gb <- gb-mg
  ghk <- t(gb)%*%(gb)  
  if(is.na(ghk)==T) ghkr <- 1000 else ghkr <- ghk
  return(ghkr)
  
}