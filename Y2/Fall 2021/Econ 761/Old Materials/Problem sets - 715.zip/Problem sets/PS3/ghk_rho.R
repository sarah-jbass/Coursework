ghk_rho=function(rho, p, n, M){
  
  #Step 1  
  s=matrix(c(1,p,p,1),2,2)
  e=mvrnorm(n, mu=c(0,0), Sigma=s)
  y1=as.numeric((e[,1]>=e[,2])&(e[,1]>=0))
  y2=as.numeric((e[,2]>=e[,1])&(e[,2]>=0))
    
  #Step 2
  id <- matrix(c(rep(0,n)),n,1)
  D <- matrix(c(rep(0,n)),n,1)
  us <- NULL
  for(m in 1:M){
    u <- runif(n)
    us <- cbind(us, u)
    eta <- qnorm(u*(1-pnorm(0))+pnorm(0))
    id <- id + (1-pnorm(0))*pnorm((1-rho)*eta/sqrt(1-rho^2))
    D <- D + (-1)*(1-pnorm(0))*dnorm((1-rho)*eta/sqrt(1-rho^2))*eta*((rho-1)/((1-rho^2)^1.5))
  }  
  id <- id/M
  G <<- colMeans(cbind(D/M, D/M))
  g1 <- y1-id
  g11 <<- g1
  g2 <- y2-id
  g22 <<- g2
  g <- cbind(g1,g2) 
  gb <- colMeans(g)
  gbs <<- gb
  ghk <- t(gb)%*%(gb)  
  datan <<- cbind(y1, y2, us)
  if(is.na(ghk)==T) ghkr <- 1000 else ghkr <- ghk
  return(ghkr)
    
}