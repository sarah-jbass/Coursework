gmm_rho <- function(rho, n, M){
  
  #Step 1  
  s <- matrix(c(1,0,0,1),2,2)
  e <- mvrnorm(n, mu=c(0,0), Sigma=s)
  y1 <- as.numeric((e[,1]>=e[,2])&(e[,1]>=0))
  y2 <- as.numeric((e[,2]>=e[,1])&(e[,2]>=0))
  
  #Step 2
  id1 <- matrix(c(rep(0,n)),n,1)
  id2 <- matrix(c(rep(0,n)),n,1)
  D1 <- matrix(c(rep(0,n)),n,1)
  D2 <- matrix(c(rep(0,n)),n,1)
  for(m in 1:M){
    u <- mvrnorm(n, mu=c(0,0), Sigma=diag(2))
    ep <- sqrtm(matrix(c(1,rho,rho,1),2,2))%*%t(u)
    eps <- rho+t(ep[1,])*t(ep[2,])-(rho/(1-rho^2))*(t(ep[1,])^2+t(ep[2,])^2-2*rho*t(ep[1,])*t(ep[2,]))
    d1 <- (-1)*t(eps*as.numeric((ep[1,]>=0)&(ep[1,]>=ep[2,])))
    D1 <- D1+d1
    d2 <- (-1)*t(eps*as.numeric((ep[2,]>=0)&(ep[2,]>=ep[1,])))
    D2 <- D2+d2
    id1 <- id1+as.numeric((ep[1,]>=0)&(ep[1,]>=ep[2,]))
    id2 <- id2+as.numeric((ep[2,]>=0)&(ep[2,]>=ep[1,]))
  }
  id1 <- id1/M
  id2 <- id2/M
  D1 <<- D1*(1/(M*(1-(rho^2))))
  D2 <<- D2*(1/(M*(1-(rho^2))))
  g1 <- y1-id1
  g2 <- y2-id2
  g <- cbind(g1,g2) 
  gb <- colMeans(g)
  gbg <<- gb
  gmm <- t(gb)%*%gb
  
  return(gmm)
  
}