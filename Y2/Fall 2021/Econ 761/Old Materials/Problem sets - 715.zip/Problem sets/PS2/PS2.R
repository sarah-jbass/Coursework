#################
# Problem set 2 #
# Natalia Serna #
#################

rm(list=ls())
library(MASS)
library(expm)
setwd("~/Documents/Ph.D/Econ 715 - Econometric Methods/Problem sets/PS2/")
source("gmm_rho.R")
set.seed(1234)
sims <- 1000
n <- 1000

#Part 2.a)
reject <- 0
rho_sims <- NULL
M <- 20
for(i in 1:sims){
  p <- optim(par=0.001, gmm_rho, n=n, M=M, lower=-1, upper=1) 
  p_hat <- p$par 
  rho_sims[i] <- p_hat
  f <- gmm_rho(rho=p_hat, n=n, M=M)
  Sig <- (gbg%*%t(gbg))/n
  G <- cbind(D1,D2)
  G <- colMeans(G)
  var <- solve(t(G)%*%G)%*%(t(G)%*%(Sig)%*%G)%*%solve(t(G)%*%G)/n
  W <- p_hat/sqrt(var)
  reject <- reject+as.numeric(abs(W)>=qnorm(0.975))
}

mean(rho_sims)
sd(rho_sims)
reject/sims




