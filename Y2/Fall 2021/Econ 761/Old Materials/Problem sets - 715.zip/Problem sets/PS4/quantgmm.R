quantgmm <- function(b, y, x, tau){
  
  m <- sweep(x, 1, t(t(as.numeric(y<=t(b%*%t(x)))))-tau, `*`)
  m <- colMeans(m)
  gmm <- t(m)%*%diag(length(b))%*%t(t(m))
  return(gmm)
}