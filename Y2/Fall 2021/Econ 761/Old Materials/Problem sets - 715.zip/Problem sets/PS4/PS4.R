#################
# Problem set 1 #
# Natalia Serna #
#################

rm(list=ls())
library(quantreg)
library(MASS)
library(doParallel)
library(doRNG)
cl <- makeCluster(2)
registerDoParallel(cl)
setwd("~/Documents/Ph.D/Econ 715 - Econometric Methods/Problem sets/PS4/")

#Load data
cps <- read.csv("cps09mar.csv", sep=";")
cps$exp <- cps$age-6-cps$education
cps <- cps[-which(cps$exp<9 | cps$exp>14),]
cps <- cps[-which(cps$education<11 | cps$education>17),]
cps$logw <- log(cps$earnings)
cps$exp2 <- (cps$exp)^2
cps$constant <- 1
attach(cps)

##### Part 1
#a)
lin <- lm(logw ~ education+exp+exp2)
slin <- summary(lin)$coefficients

#b)
qreg50 <- rq(logw ~ education+exp+exp2, tau=0.50)
qreg75 <- rq(logw ~ education+exp+exp2, tau=0.75)

#Part 1.c)
s75 <- summary(qreg75)$coefficients
s75[2,2]

#####Part 2.
#a) In pdf

#b)
source("quantgmm.R")
x <- data.matrix(cbind(constant, education, exp, exp2))
y <- t(t(logw))

beta <- optim(par=c(slin[,1]), fn=quantgmm, method="Nelder-Mead", x=x, y=y, tau=0.75, control=list(trace=T, abstol=1e-14))
beta75 <- beta$par
res75 <- y-x%*%t(t(beta75))

beta <- optim(par=c(slin[,1]), fn=quantgmm, method="Nelder-Mead", x=x, y=y, tau=0.5, control=list(trace=T, abstol=1e-14))
beta50 <- beta$par
res50 <- y-x%*%t(t(beta50))

#c) In pdf

#d)
source("quantvcov.R")
vcov75 <- quantvcov(y=y, x=x, tau=0.75, res=res75, n=nrow(x))
sqrt(diag(vcov75))
vcov50 <- quantvcov(y=y, x=x, tau=0.50, res=res50, n=nrow(x))
sqrt(diag(vcov50))

#e)
sqrt(diag(vcov75))[2]

#####Part 3.
#a) and c)
minobs <- 50
ed <- levels(as.factor(education))
ex <- levels(as.factor(exp))
grid <- expand.grid(ed,ex)
grid <- apply(grid, 2, as.character)
grid <- apply(grid, 2, as.numeric)

logw75 <- NULL
res75 <- NULL
om <- NULL
gam <- NULL
for(i in 1:nrow(grid)){
  id <- which(education==grid[i,1] & exp==grid[i,2])
  logw75 <- rbind(logw75, quantile(logw[id], 0.75))
  res <- rbind(res75, logw[id]-quantile(logw[id], 0.75))
  om <- rbind(om, 0.75*(1-0.75)*(1/(length(id)/nrow(cps))))
  gam <- rbind(gam, dnorm(0, mean=mean(res), sd=sd(res)))
}

Omega <- diag(length(om))
diag(Omega) <- om
Gamma <- diag(length(gam))
diag(Gamma) <- gam
vcov75_c <- solve(t(Gamma)%*%solve(Omega)%*%Gamma)

#b) In pdf

#d)
x <- cbind(1, grid, grid[,2]^2)
bmd <- solve(t(x)%*%solve(vcov75_c)%*%x)%*%t(x)%*%solve(vcov75_c)%*%logw75

#e) In pdf

#f)
res2 <- (logw75-t(t(bmd)%*%t(cbind(1, grid, grid[,2]^2))))^2
res <- diag(length(res2))
diag(res) <- res2
vcovmd <- (solve(t(x)%*%solve(vcov75_c)%*%x)%*%t(x)%*%solve(vcov75_c)%*%res%*%solve(vcov75_c)%*%x%*%solve(t(x)%*%solve(vcov75_c)%*%x))
sqrt(diag(vcovmd))

#####Part 4
#a) and b)
sims <- 1000
boot <- 400
minobs <- 10
tau <- 0.75

accept <- foreach(j=1:sims, .combine=rbind, .packages=c("MASS", "quantreg")) %dopar% {   
  samp <- sample.int(boot, size = boot, replace = T)
  d <- cps[samp,]
  
  #First method: quantile regression
  qreg <- rq(logw ~ education+exp+exp2, data=d, tau=0.75)
  summ <- summary(qreg75)$coefficients
  r1 <- as.numeric(slin[2,1]>=summ[2,1]-qnorm(0.975)*summ[2,2] & slin[2,1]<=summ[2,1]+qnorm(0.975)*summ[2,2])
  
  #Second method: gmm
  x <- data.matrix(d[,c("constant", "education", "exp", "exp2")])
  y <- t(t(d[,"logw"]))
  b <- optim(par=c(slin[,1]), fn=quantgmm, method="Nelder-Mead", x=x, y=y, tau=0.75, control=list(abstol=1e-14))
  bgmm <- b$par
  resgmm <- y-x%*%t(t(bgmm))
  vcovgmm <- quantvcov(y=y, x=x, tau=0.75, res=resgmm, n=nrow(x))
  vcovgmm <- sqrt(diag(vcovgmm))
  r2 <- as.numeric(slin[2,1]>=bgmm[2]-qnorm(0.975)*vcovgmm[2] & slin[2,1]<=bgmm[2]+qnorm(0.975)*vcovgmm[2])
  
  #Third method: minimum distance
  ed <- levels(as.factor(d[,"education"]))
  ex <- levels(as.factor(d[,"exp"]))
  grid <- expand.grid(ed,ex)
  grid <- apply(grid, 2, as.character)
  grid <- apply(grid, 2, as.numeric)  
  logw75 <- NULL
  res75 <- NULL
  om <- NULL
  gam <- NULL
  del <- NULL
  for(i in 1:nrow(grid)){
    id <- which(x[, "education"]==grid[i,1] & x[, "exp"]==grid[i,2])
    del <- rbind(del, as.numeric(length(id)<minobs))
    if(length(id)>=minobs){
      logw75 <- rbind(logw75, quantile(y[id], 0.75))
      res <- rbind(res75, y[id]-quantile(y[id], 0.75))
      om <- rbind(om, 0.75*(1-0.75)*(1/(length(id)/nrow(cps))))
      gam <- rbind(gam, dnorm(0, mean=mean(res), sd=sd(res)))   
    }    
  }  
  Omega <- diag(length(om))
  diag(Omega) <- om
  Gamma <- diag(length(gam))
  diag(Gamma) <- gam
  vcov75_c <- solve(t(Gamma)%*%solve(Omega)%*%Gamma)
  id <- which(del==1)
  grid <- grid[-id,]
  x <- cbind(1, grid, grid[,2]^2)
  bmd <- solve(t(x)%*%solve(vcov75_c)%*%x)%*%t(x)%*%solve(vcov75_c)%*%logw75
  res2 <- (logw75-t(t(bmd)%*%t(cbind(1, grid, grid[,2]^2))))^2
  res <- diag(length(res2))
  diag(res) <- res2
  vcovmd <- (solve(t(x)%*%solve(vcov75_c)%*%x)%*%t(x)%*%solve(vcov75_c)%*%res%*%solve(vcov75_c)%*%x%*%solve(t(x)%*%solve(vcov75_c)%*%x))
  vcovmd <- sqrt(diag(vcovmd))
  r3 <- as.numeric(slin[2,1]>=bmd[2]-qnorm(0.975)*vcovmd[2] & slin[2,1]<=bmd[2]+qnorm(0.975)*vcovmd[2])
  
  c(r1,r2,r3, summ[2,1], summ[2,2], bgmm[2], vcovgmm[2], bmd[2], vcovmd[2])
}  

apply(accept, 2, mean)
