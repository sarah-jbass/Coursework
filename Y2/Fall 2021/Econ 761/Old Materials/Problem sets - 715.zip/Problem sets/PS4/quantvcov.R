quantvcov <- function(y, x, tau, res, n){
  
  O <- tau*(1-tau)*((t(x)%*%x)/n)
  mu <- mean(res)
  s <- sd(res)
  G <- (dnorm(0, mean=mu, sd=s))*(t(x)%*%x)/n
  qvcov <- solve(t(G)%*%solve(O)%*%G)/n
  return(qvcov)
}