ghk_rho=function(rho, n){
  
  #Step 1  
  s=matrix(c(1,0.5,0.5,1),2,2)
  e=mvrnorm(n, mu=c(0,0), Sigma=s)
  e1=e[,1]
  e2=e[,2]
  y1=as.numeric((e1>=e2)&(e1>=0))
  y2=as.numeric((e2>=e1)&(e2>=0))
    
  #Step 2
  u=runif(n)
  g1=y1-(1-pnorm(0))*pnorm((1-rho)*qnorm(u*(1-pnorm(0))+pnorm(0))/sqrt(1-rho^2))
  g2=y2-(1-pnorm(0))*pnorm((1-rho)*qnorm(u*(1-pnorm(0))+pnorm(0))/sqrt(1-rho^2))
  g=rbind(g1,g2)
  gb=rowMeans(g)
  gmm=t(gb)%*%gb
  return(gmm)
  
}