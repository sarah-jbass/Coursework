gmm_rho=function(rho, n){
  
  #Step 1  
  s=matrix(c(1,0.5,0.5,1),2,2)
  e=mvrnorm(n, mu=c(0,0), Sigma=s)
  e1=e[,1]
  e2=e[,2]
  y1=as.numeric((e1>=e2)&(e1>=0))
  y2=as.numeric((e2>=e1)&(e2>=0))
  
  #Step 2
  u=mvrnorm(n, mu=c(0,0), Sigma=diag(2))
  u1=u[,1]
  u2=u[,2]
  ep=sqrtm(matrix(c(1,rho,rho,1),2,2))%*%t(u)
  ep1=ep[1,]
  ep2=ep[2,]
  g1=y1-(ep1>=0 & ep1>=ep2)
  g2=y2-(ep2>=0 & ep2>=ep1)
  g=rbind(g1,g2)
  gb=rowMeans(g)
  gmm=t(gb)%*%gb
  return(gmm)
  
}