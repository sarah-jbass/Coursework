###################
## Problem Set 1 ##
## Natalia Serna ##
###################

rm(list=ls())
library(MASS)
library(expm)
setwd("~/Documents/Ph.D/Econ 715 - Econometric Methods/Problem sets/PS1/")
source("gmm_rho.R")
source("ghk_rho.R")
set.seed(1234)
sims=1000
n=500

#Part a)
rho=NULL
for(i in 1:sims){
    p=optimize(gmm_rho,interval=c(0,1), n=n) 
    rho[i]=p$minimum
}

mean(rho)
mean(rho)-0.5
sd(rho)

#Part b)
rho=NULL
for(i in 1:sims){
  p=optimize(ghk_rho,interval=c(0,1), n=n) 
  rho[i]=p$minimum
}

mean(rho)
mean(rho)-0.5
sd(rho)

#Part c)
ni=c(1000,2000)
for(j in 1:2){
  n=ni[j]
  rhom=NULL
  rhok=NULL
  for(i in 1:sims){
    p=optimize(gmm_rho,interval=c(0,1), n=n) 
    rhom[i]=p$minimum
    p=optimize(ghk_rho,interval=c(0,1), n=n) 
    rhok[i]=p$minimum
  }  
  print(mean(rhom))
  print(mean(rhom)-0.5)
  print(sd(rhom))
  
  print(mean(rhok))
  print(mean(rhok)-0.5)
  print(sd(rhok))
}

