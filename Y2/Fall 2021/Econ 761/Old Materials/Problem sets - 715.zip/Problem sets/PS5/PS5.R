#################
# Problem set 5 #
# Natalia Serna #
#################

rm(list=ls())
library(MASS)
library(doParallel)
library(doRNG)
library(ggplot2)
cl <- makeCluster(2)
registerDoParallel(cl)
setwd("~/Documents/Ph.D/Econ 715 - Econometric Methods/Problem sets/PS5/")

#Load data
cps <- read.csv("cps09mar.csv", sep=";")
cps$exp <- cps$age-6-cps$education
cps <- cps[-which(cps$exp<9 | cps$exp>14),]
cps <- cps[-which(cps$education<11 | cps$education>17),]
cps$logw <- log(cps$earnings)
cps$exp2 <- (cps$exp)^2
cps$constant <- 1

##### Part 1
lin <- lm(logw ~ education+exp+exp2, data=cps)
slin <- summary(lin)$coefficients

##### Part 2
# a)
control <- which(education==12)
treated <- which(education==16)
lev <- unique(exp)
cate <- foreach(i=1:length(lev), .combine=rbind)%dopar%{
  id <- which(cps$exp==lev[i])
  idc <- intersect(id, control)
  idt <- intersect(id, treated)
  c <- mean(cps$logw[idt])-mean(cps$logw[idc])
  return(c)
}
cate <- data.frame(exp=lev, cate)
ggplot(cate, aes(x=exp, y=cate))+geom_line()+theme_bw()

#b)
ate <- mean(cate[,2])

##### Parts 3, 4 and 5
sims <- 500
n <- 400
subsamp <- cps[union(control, treated),]
subsamp[which(subsamp$education==12), "treatment"] <- 0
subsamp[which(subsamp$education==16), "treatment"] <- 1

ateboot <- foreach(i=1:sims, .combine=rbind, .packages=c("doParallel"))%dopar%{
  
  ### Part 3
  samp <- sample.int(nrow(subsamp), size = n, replace = T)
  d <- subsamp[samp,]  
  naive <- mean(d[which(d$education==16), "logw"])-mean(d[which(d$education==12), "logw"])
  if(is.nan(naive)==T) naive <- 0
  
  ### Part 4
  mod <- lm(logw ~ treatment+exp+exp2+treatment:exp+treatment:exp2, data=d)
  mod <- summary(mod)$coefficients
  catei <- mod[2,1]+mod[5,1]*mean(d$exp)+mod[6,1]*mean(d$exp2)
  
  ### Part 5
  scores <- foreach(j=1:length(lev), .combine=rbind)%dopar%{
    s <- length(which(d$exp==lev[j]))/nrow(d)
    s
  }
  scores <- data.frame(exp=lev, scores)
  scores <- scores[order(scores$scores, decreasing=T),]
  d <- merge(d, scores, by="exp")
  
  #ATE for lower propensity scores
  lower <- scores[c(5,6),2]
  di <- d[which(d$scores %in% lower),]
  simplel <- mean(di[which(di$treatment==1),"logw"])-mean(di[which(di$treatment==0),"logw"])
  
  #ATE for higher propensity scores
  upper <- scores[c(1,2),2]
  di <- d[which(d$scores %in% upper),]
  simpleu <- mean(di[which(di$treatment==1),"logw"])-mean(di[which(di$treatment==0),"logw"])
  
  #ATE for middle propensity scores 
  middle <- scores[c(3,4),2]
  di <- d[which(d$scores %in% middle),]
  simplem <- mean(di[which(di$treatment==1),"logw"])-mean(di[which(di$treatment==0),"logw"])
  
  #Overall ATE
  ate <- (simplel+simpleu+simplem)/3
  
  return(c(naive, catei, ate))
  
}

##### Plots
atesim <- data.frame(SimulatedATE=ateboot[,1])
ggplot(atesim, aes(x=SimulatedATE))+geom_histogram(color="deepskyblue3", fill="lightblue")+
  geom_vline(aes(xintercept=slin[2]*4), color="red", size=1)+
  geom_vline(aes(xintercept=ate), color="black", size=1)+
  annotate("text", label = "4~beta^{edu}", parse = TRUE, x = 0.701, y = 40, color = "black", size=5)+
  annotate("text", label = "ATE", parse = TRUE, x = 0.7, y = 35, color = "red", size=5)+ theme_bw()

catesim <- data.frame(SimulatedCATE=ateboot[,2])
ggplot(catesim, aes(x=SimulatedCATE))+geom_histogram(color="deepskyblue3", fill="lightblue")+
  geom_vline(aes(xintercept=slin[2]*4), color="red", size=1)+
  geom_vline(aes(xintercept=ate), color="black", size=1)+
  annotate("text", label = "4~beta^{edu}", parse = TRUE, x = 0.701, y = 40, color = "black", size=5)+
  annotate("text", label = "ATE", parse = TRUE, x = 0.7, y = 35, color = "red", size=5)+ theme_bw()

propsim <- data.frame(SimulatedPropScoreATE=ateboot[,3])
ggplot(propsim, aes(x=SimulatedPropScoreATE))+geom_histogram(color="deepskyblue3", fill="lightblue")+
  geom_vline(aes(xintercept=slin[2]*4), color="red", size=1)+
  geom_vline(aes(xintercept=ate), color="black", size=1)+
  annotate("text", label = "4~beta^{edu}", parse = TRUE, x = 0.701, y = 40, color = "black", size=5)+
  annotate("text", label = "ATE", parse = TRUE, x = 0.7, y = 35, color = "red", size=5)+ theme_bw()



